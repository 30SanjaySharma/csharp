﻿// See https://aka.ms/new-console-template for more information
using AssemblyA;
using NewAssembly;

Console.WriteLine("Hello, World!");
//MyClass myClass = new MyClass();
//myClass.ProtectedInternalMember = 10;

//Singleton.GetInstance();
//Singleton.GetInstance(

//Animal animal = new Dog();

//animal.MakeSound();
//animal.TestAnimal();

var word = "helLo";

//Console.WriteLine(word.Count(x => word.Contains(x)));

var splitWord = word.ToCharArray().Select(c => c.ToString()).ToArray();
var wordReaded = "";

var adata = word.GroupBy(x => x).ToDictionary(kvp => kvp.Count(), kvp => kvp.Key);

Console.WriteLine();

//foreach (var split in splitWord)
//{
//    if (wordReaded.ToLower() == split.ToString().ToLower())
//        continue;

//    Console.WriteLine(split);
//    Console.WriteLine(word.Count(x => x.ToString().ToLower() == split.ToString().ToLower()));
//    wordReaded = split.ToString();
//}

//foreach (var split in splitWord)
//{
//    if (wordReaded.ToLower() == split.ToString().ToLower()  )
//        continue;

//    Console.WriteLine(split);
//    Console.WriteLine(word.Count(x => x.ToString().ToLower() == split.ToString().ToLower()));
//    wordReaded = split.ToString();
//}
