﻿using AssemblyA;

namespace AssemblyB
{
    public class DerivedClass : MyClass
    {
        public void AccessMembers()
        {
            // Both ProtectedInternalMember and PublicMember are accessible
            // ProtectedInternalMember is accessible because it's protected internal
            // PublicMember is accessible because it's public
            ProtectedInternalMember = 10;
            PublicMember = 20;
        }
    }

    public class OtherClass
    {
        public void AccessMembers()
        {
            MyClass myObj = new MyClass();
            // PublicMember is accessible
            myObj.PublicMember = 30;

            // Error: ProtectedInternalMember is not accessible from a different assembly
            myObj.ProtectedInternalMember = 40;

            Console.WriteLine($"data:- {myObj.ProtectedInternalMember}");
        }
    }
}