﻿namespace TestApp
{
    // Another class in the same assembly
    public class AnotherClass
    {
        public void AccessProtectedInternal()
        {
            MyBaseClass baseClass = new MyBaseClass();
            // Accessing protected internal method from the same assembly
            baseClass.ProtectedInternalMethod();

            baseClass.ProtectedInternalMethodInternal();

            InternalClass internalClass = new InternalClass();
            internalClass.GetInternalValue();

        }
    }
}
