﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp
{
    public abstract class AbstractClass
    {
        public string Name { get; set; }

        public abstract string Test();

        public string TestSimple()
        {
            return Name;
        }

        public virtual string TestVirtual()
        {
            throw new NotImplementedException();
        }

        public int RefMethod(ref int number)
        {
            return number;
        }


        public void CallRefMethod()
        {
            int number = 10;
            Console.WriteLine(RefMethod(ref number));



        }

        public string OverloadMethod(int i)
        {
            return "";
        }

        public string OverloadMethod(string i)
        {
            return "";
        }

    }
}
