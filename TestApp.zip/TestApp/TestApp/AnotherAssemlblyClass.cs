﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestApp;

namespace TestingNewApp
{
    public class AnotherAssemlblyClass
    {
        public void AnotherAssembolyMehotd()
        {
            InternalClass internalClass = new InternalClass();
            internalClass.GetInternalValue();
        }
    }
}
