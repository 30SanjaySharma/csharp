﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp
{
    public class MyDerivedClass : MyBaseClass
    { 
        public void AccessProtectedMembers()
        {
            // Accessing protected member from the base class
            Console.WriteLine("Value of protectedField from derived class: " + protectedField);

            protectedField = 14;

            // Accessing protected method from the base class
            ProtectedMethod();

            // Accessing protected method from the base class
            ProtectedInternalMethod();
        }
    }
}
