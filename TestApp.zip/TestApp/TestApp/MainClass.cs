﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp
{
    public class MainClass : AbstractClass
    {
        public override string Test()
        {
            return TestSimple();
        }

        public override string TestVirtual()
        {
            return "";
        }
    }

    public class Animal
    {
        public virtual void MakeSound()
        {
            Console.WriteLine("Animal makes a sound");
        }
    }

    public class Dog : Animal
    {
        public int Value;
        public override void MakeSound()
        {
            Console.WriteLine("Dog barks");
        }

        public static Dog Copy(Dog original)
        {
            Dog copy = new Dog();
            copy.Value = original.Value;
            return copy;
        }

        public void Test()
        {

        }
    }

    public class Cat : Animal
    {
        public static int Value;
        static Cat()
        {
            Value = 10;
        }

        public void Test()
        {
            base.MakeSound();

            Dog.Copy(new Dog());

            Singleton.GetInstance();



        }


    }
}
