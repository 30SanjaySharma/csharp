﻿namespace AssemblyA
{
    public class MyClass
    {
        protected internal int ProtectedInternalMember;
        public int PublicMember;
    }
}
