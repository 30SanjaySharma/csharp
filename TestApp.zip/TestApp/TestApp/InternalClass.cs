﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp
{
    internal class InternalClass
    {
        internal int data = 20;

        internal int GetInternalValue()
        {
            return data;
        }
    }
}
