﻿using AssemblyA;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp
{
    public class MyBaseClass
    {
        // Protected field accessible within the class and derived classes
        protected int protectedField = 10;


        public MyBaseClass()
        {

        }

        public MyBaseClass(int protectedField)
        {
            this.protectedField = protectedField;
        }


        // Protected method accessible within the class and derived classes
        protected void ProtectedMethod()
        {
            Console.WriteLine("Protected Method called");
        }

        // Protected internal method accessible within the same assembly or derived classes in other assemblies
        protected internal void ProtectedInternalMethod()
        {
            Console.WriteLine("Protected Internal Method called");
        }
        internal void ProtectedInternalMethodInternal()
        {
            Console.WriteLine("Protected Internal Method called");
        }

        public void AccessMembers()
        {
            MyClass myObj = new MyClass();
            // PublicMember is accessible
            myObj.PublicMember = 30;

            // Error: ProtectedInternalMember is not accessible from a different assembly
            myObj.ProtectedInternalMember = 40;

            Console.WriteLine($"data:- {myObj.ProtectedInternalMember}");
        }
    }
}
