﻿// See https://aka.ms/new-console-template for more information
using AssemblyA;
using AssemblyB;

Console.WriteLine("Hello, World!");
